Group A 
Name: Roshan R(120050082)
	  Deepanjan Kundu(120050009)

Group B
Name:Sanket Kanjalkar (120050011)
	Karan Ganju (120050021)


Add a well documented and commented code of your experiments in the respective folders.
