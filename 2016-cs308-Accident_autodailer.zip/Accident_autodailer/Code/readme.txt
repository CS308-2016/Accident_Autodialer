2016 - CS308  Group X : Project README TEMPLATE 
================================================ 
 
Group Info: 
------------ 
+   Student Name (Roll Number) 
+   Student Name (Roll Number) 
 
Extension Of 
------------ 
 
Have you extended your project from any other past porjects? Please mention the title here.  
 
Project Description 
------------------- 
 
This is a reame template. It is written using markdown syntax. To know more about markdown you can alwats refer to [Daring Fireball](http://daringfireball.net/projects/markdown/basics).  
You can preview how your mardown looks when rendered [here](http://daringfireball.net/projects/markdown/dingus) 
 
Students are requested to use this format for the sake of uniformity and convinience. Also we can parse these files and then index them for easy searching.  
 
Technologies Used 
------------------- 
 
Remove the items that do no apply to your project and keep the remaining ones. 
 
+   Embedded C 
+   uCos 
+   RTAI 
+   MATLAB 
+   Scilab 
+   Xbee 
+   JAVA 
+   Python 
+   Android 
+   Kinect 
+   Specialized Hardware 
+   Gripper 
+   Robotic Arm 
+   OpenCV 
    
 
 
Installation Instructions 
========================= 
 
If you need any software such as scilab, OpenCV etc. Please provide [links](http://example.com) to all these software.  
 
 
Demonstration Video 
=========================  
Add the youtube link of the screencast of your project demo.

References 
=========== 
 
Please give references to importance resources.  
 
+ [Title](http://example.org) 
+ [Title](http://example.org) 
+ [Title](http://example.org)

